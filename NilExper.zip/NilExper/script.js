const emailinput = document.querySelector("#email");

const passwordlinput = document.querySelector("#password");

const entrarBtn = document.querySelector("#btnEntrar");

const form = document.querySelector("#form")

entrarBtn.addEventListener("click", (e) =>{
    e.preventDefault();
    if (emailinput.value  == ""){
       alert("Coloque seu e-mail!");
       return; 
    }
    if (passwordlinput.value  == ""){
       passwordlinput.style.backgroundColor = "red";
       alert("Coloque sua senha!");

       setTimeout(() => {
        passwordlinput.style.backgroundColor = "white"
       }, 5000);
       
       return;
    }
});